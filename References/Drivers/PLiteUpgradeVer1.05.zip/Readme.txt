Version 1.05 

Adds support for the HI-6022